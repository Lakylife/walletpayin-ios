import Foundation

class CurrentDateProvider {

    var currentDate: Date {
        Date()
    }

}
