import Foundation
import UIKit
import MarketKit

struct AppConfig {
    static let label = "io.walletpayin.app"
    static let backupSalt = "walletpayin"

    static let companyName = "Walletpayin Community"
    static let reportEmail = "support@walletpayin.com"
    static let companyWebPageLink = "https://walletpayin.com"
    static let appWebPageLink = "https://walletpayin.com/wallet"
    static let analyticsLink = "https://walletpayin.com/analytics"
    static let appGitHubAccount = "lakylife"
    static let appGitHubRepository = "walletpayin-app-ios"
    static let appTwitterAccount = "walletpayin"
    static let appTelegramAccount = "walletpayin"
    static let appRedditAccount = "walletpayin"
    static let mempoolSpaceUrl = "https://mempool.space"
    static let guidesIndexUrl = URL(string: "https://walletpayin.com/blockchain/v1/index.json")!
    static let faqIndexUrl = URL(string: "https://walletpayin.com/blockchain/faq.json")!
    static let donationAddresses: [BlockchainType: String] = [
        .bitcoin: "1MTsLPCXhUmVqht1yTmu12WHtSsfqapAZp",
        .bitcoinCash: "bitcoincash:1MTsLPCXhUmVqht1yTmu12WHtSsfqapAZp\n",
        .ecash: "ecash:qrem8dt4jckmvden5p4cl6edlw9fm53l85u9d6fuh2",
        .litecoin: "La7wVC1veonriZFkrAzsDUEoaZW3Sq6BC5",
        .dash: "XatvcM6wHK6KtiPPMN8W4sWRgtPL2UBEDq",
        .zcash: "zs1jpd8u7zghtq5eg48l384y6fpy7cr0xmqehnw5mujpm8v2u7jr9a3j7luftqpthf6a8f720vdfyn",
        .ethereum: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .binanceSmartChain: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .binanceChain: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .polygon: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .avalanche: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .optimism: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .arbitrumOne: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .gnosis: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .fantom: "0x9b5d3b6db1c2262dfed76d2d2946e9f01598c428",
        .tron: "TWRamSaARpqERpd8MB4hBjfgE9WDq9U2Zs",
        .solana: "7bEBR27etrteRecLVu9XvHJUihtgfZgw3uXdcAu3J5is"
    ]

    static var appVersion: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
    }

    static var appBuild: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
    }

    static var appId: String? {
        UIDevice.current.identifierForVendor?.uuidString
    }

    static var appName: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String) ?? ""
    }

    static var marketApiUrl: String {
        (Bundle.main.object(forInfoDictionaryKey: "MarketApiUrl") as? String) ?? ""
    }

    static var officeMode: Bool {
        Bundle.main.object(forInfoDictionaryKey: "OfficeMode") as? String == "true"
    }

    static var infuraCredentials: (id: String, secret: String?) {
        let id = (Bundle.main.object(forInfoDictionaryKey: "InfuraProjectId") as? String) ?? ""
        let secret = Bundle.main.object(forInfoDictionaryKey: "InfuraProjectSecret") as? String
        return (id: id, secret: secret)
    }

    static var etherscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "EtherscanApiKey") as? String) ?? ""
    }

    static var arbiscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "ArbiscanApiKey") as? String) ?? ""
    }

    static var gnosisscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "GnosisscanApiKey") as? String) ?? ""
    }

    static var ftmscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "FtmscanApiKey") as? String) ?? ""
    }

    static var optimismEtherscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "OptimismEtherscanApiKey") as? String) ?? ""
    }

    static var bscscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "BscscanApiKey") as? String) ?? ""
    }

    static var polygonscanKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "PolygonscanApiKey") as? String) ?? ""
    }

    static var snowtraceKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "SnowtraceApiKey") as? String) ?? ""
    }

    static var cryptoCompareApiKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "CryptoCompareApiKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var defiYieldApiKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "DefiYieldApiKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var twitterBearerToken: String? {
        (Bundle.main.object(forInfoDictionaryKey: "TwitterBearerToken") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var hsProviderApiKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "HsProviderApiKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var tronGridApiKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "TronGridApiKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var walletConnectV2ProjectKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "WallectConnectV2ProjectKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var walletpayinDomainsApiKey: String? {
        (Bundle.main.object(forInfoDictionaryKey: "WalletpayinDomainsApiKey") as? String).flatMap { $0.isEmpty ? nil : $0 }
    }

    static var defaultWords: String {
        Bundle.main.object(forInfoDictionaryKey: "DefaultWords") as? String ?? ""
    }

    static var defaultPassphrase: String {
        Bundle.main.object(forInfoDictionaryKey: "DefaultPassphrase") as? String ?? ""
    }

    static var sharedCloudContainer: String? {
        Bundle.main.object(forInfoDictionaryKey: "SharedCloudContainerId") as? String
    }

    static var privateCloudContainer: String? {
        Bundle.main.object(forInfoDictionaryKey: "PrivateCloudContainerId") as? String
    }

    static var openSeaApiKey: String {
        (Bundle.main.object(forInfoDictionaryKey: "OpenSeaApiKey") as? String) ?? ""
    }

}
