import ThemeKit
import UIExtensions
import UIKit

class BlurManager {
    private let coverView = UIView()
    private let logoImageView = UIImageView()

    private let lockManager: LockManager
    private var shown = false

    var isEnabled = true

    init(lockManager: LockManager) {
        self.lockManager = lockManager


    }

    private func show() {
        logoImageView.image = UIImage(named: AppIconManager.currentAppIcon.imageName)

        let window = UIApplication.shared.windows.first { $0.isKeyWindow }
        let frame = window?.frame ?? UIScreen.main.bounds

        coverView.alpha = 1
        coverView.frame = frame
        window?.addSubview(coverView)
        shown = true
    }
}

extension BlurManager {
    func willResignActive() {
        if !lockManager.isLocked, isEnabled {
            show()
        }
    }

    func didBecomeActive() {
        guard shown else {
            return
        }

        shown = false

        UIView.animate(withDuration: 0.15, animations: {
            self.coverView.alpha = 0
        }, completion: { _ in
            self.coverView.removeFromSuperview()
        })
    }

    func willEnterForeground() {
        shown = false
        coverView.removeFromSuperview()
    }
}
