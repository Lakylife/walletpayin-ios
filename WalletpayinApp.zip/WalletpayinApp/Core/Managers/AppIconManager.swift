import RxSwift
import RxRelay
import StorageKit
import UIKit

class AppIconManager {
    static let allAppIcons: [AppIcon] = [
        .main,
        .alternate(name: "AppIconDark", title: "White"),
        .alternate(name: "AppIconMono", title: "Best"),
        .alternate(name: "AppIconLeo", title: "Blue"),
        .alternate(name: "AppIconMustang", title: "Gold"),
        .alternate(name: "AppIconYak", title: "VIP"),
        .alternate(name: "AppIconPunk", title: "Bullish"),
        .alternate(name: "AppIcon1874", title: "Moon"),
        .alternate(name: "AppIcon8ball", title: "Black")
    ]

    private let appIconRelay = PublishRelay<AppIcon>()
    var appIcon: AppIcon {
        didSet {
            appIconRelay.accept(appIcon)
            UIApplication.shared.setAlternateIconName(appIcon.name)
        }
    }

    init() {
        appIcon = Self.currentAppIcon
    }

}

extension AppIconManager {

    var appIconObservable: Observable<AppIcon> {
        appIconRelay.asObservable()
    }

    static var currentAppIcon: AppIcon {
        if let alternateIconName: String = UIApplication.shared.alternateIconName, let appIcon = allAppIcons.first(where: { $0.name == alternateIconName }) {
            return appIcon
        } else {
            return .main
        }
    }

}
