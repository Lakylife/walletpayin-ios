import UIKit

extension String {

    var headerImageUrl: String {
        let scale = Int(UIScreen.main.scale)
        return "https://walletpayin.com/images/header-images/\(self)@\(scale)x.png"
    }

}
