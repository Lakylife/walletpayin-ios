import ThemeKit

extension ThemeMode: Codable {}
