import MarketKit

extension TokenQuery {

    var customCoinUid: String {
        "custom-\(id)"
    }

}

