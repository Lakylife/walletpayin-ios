import UIKit
import MarketKit

extension CoinCategory {

    var imageUrl: String {
        let scale = Int(UIScreen.main.scale)
        return "https://walletpayin.com/images/category-icons/\(uid)@\(scale)x.png"
        
    }

}
