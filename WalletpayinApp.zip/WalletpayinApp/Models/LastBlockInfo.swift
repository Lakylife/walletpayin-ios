struct LastBlockInfo {
    let height: Int
    let timestamp: Int?
}
