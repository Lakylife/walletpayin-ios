enum SyncMode_v_0_24: String {
    case fast
    case slow
    case new
}
