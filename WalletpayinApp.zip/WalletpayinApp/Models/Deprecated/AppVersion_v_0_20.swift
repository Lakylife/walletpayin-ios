import Foundation

struct AppVersion_v_0_20: Codable {
    var version: String
    var date: Date
}
