import Foundation

struct NftContractMetadata: Equatable {
    let address: String
    let name: String
    let schema: String?
}
