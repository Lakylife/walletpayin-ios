enum AdapterError: Error {
    case wrongParameters
    case unsupportedAccount
}
